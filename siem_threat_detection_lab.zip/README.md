# 🔐 SIEM Threat Detection Lab

This project simulates cyberattack behaviors in a virtual lab and uses Splunk (SIEM) to detect and analyze these activities through event logs. It demonstrates log correlation, alerting, and threat detection aligned with the MITRE ATT&CK framework.

## 🔧 Tools Used
- Splunk (Free Tier)
- Windows 10 Event Viewer
- MITRE ATT&CK Navigator
- PowerShell (Simulated attack commands)

## 🧪 Simulated Behaviors Detected
- Multiple failed login attempts (Brute Force - T1110)
- PowerShell execution (Command & Control - T1059)
- Suspicious file download (T1105)
- Unusual port traffic (T1043)

## 📁 Files Included
- `splunk-threat-detection-report.docx` – Summary report
- `splunk-search-queries.docx` – SPL queries used
- `log-analysis-summary.docx` – Interpreting key log events

## 🧠 Skills Demonstrated
- SIEM log analysis
- SPL query writing
- Threat detection & documentation
- MITRE ATT&CK mapping
- Cybersecurity report writing

## ✅ Status
Project Complete ✅ – Ready for GitHub, LinkedIn, or job applications.
